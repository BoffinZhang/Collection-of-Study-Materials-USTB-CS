## 0. 基本思路
沿着数据通路添加指令。
opcode.v -> funct.v -> RegGen.v -> OperandGen.v -> Funct.v -> EX.v
对于分支指令，还需要修改BranchGen.v
对于访存指令，还需要修改MEM.v

## 0. 修改define文件
主要修改`opcode.v`和`funct.v`两个文件，查阅文档，模仿照抄即可。

#### 修改opcode.v
```verilog
// -- Extended --
// j-type
`define OP_J          6'b000010
`define OP_JR         6'b000000

// branch
`define OP_BGEZ       6'b000001     
`define OP_BGTZ       6'b000111
`define OP_BLEZ       6'b000110
`define OP_BLTZ       6'b000001

// arithmetic
`define OP_SLTI       6'b001010
`define OP_SLTIU      6'b000000
`define OP_ANDI       6'b001100
`define OP_NOR        6'b000000
`define OP_ORI        6'b001101
`define OP_XORI       6'b001110
`define OP_SRA        6'b000000
`define OP_SRL        6'b000000

// memory accessing
`define OP_LH         6'b100001
`define OP_LHU        6'b100101
`define OP_SH         6'b101001
```

#### 修改funct.v


## 分支指令的扩展
### 1. J
功能描述：无条件跳转。
J指令很简单，直接在ID级的`BranchGen.v`中添加：
```verilog
`OP_J: begin
branch_flag <= 1;
branch_addr <= {addr_plus_4[31:28], jump_addr, 2'b00};
end
```

### 2. JR
功能描述：**无条件跳转**到目标寄存器rs中的值
JR的opcode是`SPECIAL`，funct是`6'b001000`，在ID级结束

**修改funct.v**
```v
// -- Extend --
// jump
`define FUNCT_JR        6'b001000
```

**修改`BranchGen,v`**
```v
`OP_SPECIAL: begin
        if (funct == `FUNCT_JALR) begin
          branch_flag <= 1;
          branch_addr <= reg_data_1;
        end
        else if(funct == `FUNCT_JR) begin
          branch_flag <= 1;
          branch_addr <= reg_data_1;
        end
        else begin
          branch_flag <= 0;
          branch_addr <= 0;
        end
      end
```


### 3. BGEZ
opcode: 000001
inst[20:16]: 00001
**注意：** BGEZ和BLTZ的opcode相同，需要额外判断

### 4. BLTZ
opcode: 000001
inst[20:16]: 00000

### 5. BGTZ
opcode: 000111
inst[20:16]: 00000

### 6. BLEZ
opcode: 000110
inst[20:16]: 00000

上面这几条Branch指令，修改顺序均为：
opcode.v -> RegGen.v -> BranchGen.v


### 立即数


### 3. ANDI
这是一条逻辑运算指令，跟在addiu后面加就行了
主要修改`id(RegGen.v/OperandGen.v/Funct.v)`

### 4. NOR
R型指令（操作码为SPECIAL：6'b000000）
读取两个寄存器，写回rs，进行或非操作 not or 

修改`EX.v`:
```
`FUNCT_NOR: result <= ~(operand_1|operand_2);
```

### 5. ORI
I型指令
修改opcode.v -> OperandGen.v -> FunctGen.v -> EX.v

### 6. XORI
I型指令，同上

### 7. SRA
opcode: SPECIAL
funct: 000011
算数右移
如果在这里出现问题，则加上对25:21位全0的判断

注意实现过程中，shamt代表的是10:6位的数据，因此仿照上面的SRAV，在`EX.v`中补充：
```v
`FUNCT_SRA: result <= ({32{operand_2[31]}} << (6'd32 - {1'b0, shamt})) | operand_2 >> shamt;
```

### 8. SRL
opcode: SPECIAL
funct: 000010
逻辑右移


### 9. SLTI
opcode: 001010
修改：opcode.v -> OperandGen.v -> FunctGen.v -> EX.v
注意SLTI和SLT都是有符号数比较

```v
if GPR[rs] < Sign_extend(imm) then
	GPR[rt] <- 1
else
	GPR[rt] <- 0
endif
```
仿照上面实现的SLT和SLTU实现

### 10. SLTIU
opcode: 001011
修改：opcode.v -> OperandGen.v -> FunctGen.v -> EX.v

注意SLTIU和SLTU都是无符号数比较

将寄存器 rs 的值与**有符号扩展**至 32 位的立即数 imm **进行无符号数比较**，如果寄存器 rs 中的值小，则寄存器 rt置 1；否则寄存器 rt置 0。




### 15. LH
### 16. LHU
15/16都参照此前实现的LB，LBU实现即可
修改：opcode.v -> RegGen.v -> FunctGen.v -> OperandGen.v -> MemGen.v -> MEM.v -> WB.v

### 17. SH



### 测试
J:
```v
24 08 00 01   // addiu $8, $0, 1
25 08 00 02   // addiu $8, $8, 2
08 00 00 06   // j 0x6
00 00 00 00   // nop
25 08 00 03   // addiu $8, $8, 3
25 08 00 04   // addiu $8, $8, 4
25 08 00 05   // addiu $8, $8, 5
25 08 00 06   // addiu $8, $8, 6
```

ANDI:
```v
24 08 00 fa   // addiu $8,$0,0xFA
31 09 00 c1   // andi  $9,$8,0xC1
```

LH:
```v
24 08 00 04   // addiu $8,$0,0x4
24 09 0f 02   // addiu $9,$0,0x0F02
ad 09 00 00   // sw    $9,0($8)
85 0a 00 00   // lh    $10,0($8)
85 0b 00 02   // lh    $11,2($8)
```